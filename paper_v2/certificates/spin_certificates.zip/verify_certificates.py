"""Verify the spin propositions, gain interval and exact microscopic inputs."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--receipt", type=Path, help="optional path for the verification records"
    )
    args = parser.parse_args()
    with TemporaryDirectory() as directory:
        records = {}
        for name, entrypoint in [
            ("base", "evidence/certificate_review/verify.py"),
            ("exact_generator_and_spectrum", "evidence/review_audit/exact_inputs.py"),
            ("matched_gain_interval", "evidence/scaling/verify_family.py"),
            ("fixed_coupling_boxes", "evidence/neighborhood_fixed/certify_boxes.py"),
            ("matched_coupling_boxes", "evidence/neighborhood_matched/verify.py"),
            ("coherence_intervention", "evidence/coherence_control/check_balls.py"),
            ("full_channel_reduction", "evidence/reduction_check/check.py"),
        ]:
            destination = Path(directory) / (name + ".json")
            subprocess.run(
                [sys.executable, str(ROOT / entrypoint), "--receipt", str(destination)],
                check=True,
            )
            records[name] = json.loads(destination.read_text())
    if args.receipt is not None:
        args.receipt.write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
