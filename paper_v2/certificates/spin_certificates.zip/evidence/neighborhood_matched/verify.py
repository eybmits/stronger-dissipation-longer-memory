"""Uniform Arb enclosure on boxes of static XX couplings for the matched-drive proposition."""

import argparse
import itertools
import json
import sys
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
for name in ("bridge", "scaling", "review_audit"):
    sys.path.insert(0, str(HERE.parent / name))

import flint
import numpy as np
from flint import acb, arb, arb_mat as M, fmpq
from certify import block, eye, geometry, interval
from certify_matched import cmatrix, gram, hamiltonian, qutrit_basis
from continuous import block_exp
from exact_inputs import dark_polynomial, dyadic_floor, sturm_chain, variations


def minimum(values, label):
    lower = min(z.lower() for z in values)
    if not lower > 0:
        raise ArithmeticError(f"{label} is not certified positive: {lower}")
    return lower


@lru_cache(maxsize=4)
def dark_center(seed):
    hd, xd = hamiltonian(seed)
    dark = M(
        [
            [0, 2 / arb(6).sqrt()],
            [1 / arb(2).sqrt(), 1 / arb(6).sqrt()],
            [-1 / arb(2).sqrt(), 1 / arb(6).sqrt()],
        ]
    )
    pairs = []
    for i, j in itertools.combinations(range(3), 2):
        xx = M(3, 3)
        for a, b in itertools.product(range(2), repeat=2):
            xx[a + 1, b + 1] = dark[i, a] * dark[j, b] + dark[j, a] * dark[i, b]
        pairs.append(xx)
    return hd, xd, pairs


def spectral_data(row, bonds, width):
    """Enclose every perturbed spectral projector using point Sturm certificates and Weyl."""
    centers = np.random.default_rng(row["seed"]).uniform(-1, 1, 3)
    hd, xd, pairs = dark_center(row["seed"])
    for q, h0, h in zip(bonds, centers, pairs):
        center = Fraction(float(h0))
        hd = hd + (arb(q[0]) / q[1] - arb(center.numerator) / center.denominator) * h
    # Each compressed XX pair has operator norm at most one; Weyl thus
    # bounds the ordered eigenvalue shifts by the sum of the three radii.
    shift = arb(0, 3 * width)

    chain = sturm_chain(dark_polynomial([fmpq(n, d) for n, d in bonds]))
    denom = 1 << 150
    central = []
    mid = sorted([z.real for z in hd.eig()], key=lambda x: float(x.mid()))
    for z in mid:
        left = dyadic_floor(z.mid(), 150)
        poly_left, poly_right = fmpq(left, denom), fmpq(left + 1, denom)
        assert chain[0](poly_left) != 0 and chain[0](poly_right) != 0
        assert variations(chain, poly_left) - variations(chain, poly_right) == 1
        central.append((arb(left) / denom).union(arb(left + 1) / denom))
    energies = [e + shift for e in central]
    assert energies[0] < energies[1] < energies[2]
    phases = [acb(1)] + [
        acb(0, (a - b) / 2).exp()
        for i, a in enumerate(energies)
        for j, b in enumerate(energies)
        if i != j
    ]
    sep = minimum(
        [abs(a - b) for a, b in itertools.combinations(phases, 2)], "phase separation"
    )
    projectors = []
    for i, ei in enumerate(central):
        proj = eye(3)
        for j, ej in enumerate(central):
            if i != j:
                proj = proj * (hd - ej * eye(3)) / (ei - ej)
        gap = min(abs(ei - ej).lower() for j, ej in enumerate(central) if i != j)
        assert gap > 3 * width
        angle = arb(0, (3 * width / (gap - 3 * width)).upper())
        proj = M([[proj[a, b] + angle for b in range(3)] for a in range(3)])
        projectors.append(cmatrix(proj))
    tb = qutrit_basis()
    proj = M([[(t * p).trace().real for p in projectors] for t in tb])
    phi = [block(proj, range(1, 9), [i]) for i in range(3)]
    x = (phi[0] - phi[1]) / arb(2).sqrt()
    y = (phi[0] + phi[1] - 2 * phi[2]) / arb(6).sqrt()
    basis = [
        x * x.transpose(),
        y * y.transpose(),
        (x * y.transpose() + y * x.transpose()) / arb(2).sqrt(),
    ]
    for pi, pj in itertools.combinations(projectors, 2):
        plane = M(
            [
                [(a * (pi * b * pj + pj * b * pi)).trace().real for b in tb[1:]]
                for a in tb[1:]
            ]
        )
        basis.append(plane / arb(2).sqrt())
    return proj, basis, projectors, cmatrix(xd), energies, sep


def negative_symmetric_part(K):
    """Certify -K-K^T positive definite by symmetric Gaussian elimination."""
    L = -(K + K.transpose())
    pivots = []
    for k in range(L.nrows()):
        pivots.append(L[k, k])
        minimum([L[k, k]], "symmetric dissipation pivot")
        for j in range(k + 1, L.nrows()):
            for i in range(j, L.nrows()):
                L[i, j] = L[j, i] = L[i, j] - L[i, k] * L[j, k] / L[k, k]
    return minimum(pivots, "symmetric dissipation pivots")


def certify_box(row, bonds, width, geom):
    _, R, LT, S, base, drive, pairs = geom
    proj, basis, projectors, xd, energies, sep = spectral_data(row, bonds, width)
    H = base + sum(
        ((arb(n) / d + arb(0, width)) * h for (n, d), h in zip(bonds, pairs)), M(64, 64)
    )
    aug = block_exp(LT * H * R / 2, 4 * LT * drive * R, -LT * H * S * H * R / 2)
    E = block(aug, range(9), range(9))
    D1 = block(aug, range(9), range(9, 18))
    E1 = block(aug, range(9), range(18, 27))
    rates = proj.transpose() * E1 * proj
    # An off-diagonal is the right derivative at zero of a nonnegative
    # population transition that vanishes at zero. Tree weights give the
    # stationary probabilities and are positive once the graph is irreducible.
    for i, j in itertools.permutations(range(3), 2):
        assert rates[i, j].upper() >= 0
        rates[i, j] = rates[i, j].max(arb(0))
    tree = []
    for i in range(3):
        j, k = [m for m in range(3) if m != i]
        tree.append(
            rates[i, j] * rates[i, k]
            + rates[i, j] * rates[j, k]
            + rates[i, k] * rates[k, j]
        )
    tree_min = minimum(tree, "irreducible population trees")
    pmin = minimum([w / sum(tree, arb(0)) for w in tree], "stationary probabilities")
    O, d, e = (block(z, range(1, 9), range(1, 9)) for z in [E, D1, E1])
    B = M(
        [
            [gram(a, e * b * O.transpose() + O * b * e.transpose()) for b in basis]
            for a in basis
        ]
    )
    T = B + M([[gram(a, d * b * d.transpose()) for b in basis] for a in basis])
    hB = negative_symmetric_part(B)
    hT = negative_symmetric_part(T)
    contributions = []
    drive_norm_upper = arb(0)
    total = sum(tree, arb(0))
    for coherence, (i, j) in enumerate(itertools.combinations(range(3), 2), start=3):
        cross = projectors[i] * xd * projectors[j]
        # Frobenius norm of a rank-one block equals |<i|X1|j>|.
        xlower = (
            sum((abs(z).lower().max(arb(0)) ** 2 for z in cross.entries()), arb(0))
            .sqrt()
            .lower()
        )
        xupper = min(
            arb(2).sqrt(),
            sum((abs(z).upper() ** 2 for z in cross.entries()), arb(0)).sqrt().upper(),
        )
        pop_difference = abs((tree[i] - tree[j]) / total)
        delta = energies[i] - energies[j]
        response = 4 * abs(acb(0, delta / 2).exp() - 1) / abs(delta)
        # The projected drive Hamiltonian equals X1/2, with gain prefactor 8.
        drive_norm_upper += (
            2 * (xupper * min(pop_difference.upper(), arb(1)) * response.upper()) ** 2
        )
        plower = pop_difference.lower()
        if xlower > 0 and plower > 0:
            vlower = (xlower * plower * response).lower()
            decay_upper = (-B[coherence, coherence]).upper()
            assert vlower > 0 and decay_upper > 0
            contributions.append((2 * (xlower * vlower) ** 2 / decay_upper).lower())
    if not contributions:
        raise ArithmeticError(
            "No visible coherence with unequal stationary populations certified"
        )
    # The covariance solve is bounded in Frobenius coordinates. The sharper
    # denominator bound is optional: every physical scalar denominator is <= 1.
    denominator_upper = arb(1)
    try:
        inv = (-T).inv()
        inv_frob = sum((z.abs_upper() ** 2 for z in inv.entries()), arb(0)).sqrt()
        upper = 4 * inv_frob * drive_norm_upper / 3 + arb(1) / 1000
        if upper.is_finite() and upper.upper() < 1:
            denominator_upper = upper.upper()
    except (ValueError, ZeroDivisionError):
        pass
    recall = (sum(contributions, arb(0)) / denominator_upper).lower()
    minimum([recall], "measured recall lower bound")
    return dict(
        seed=row["seed"],
        couplings_as_integer_ratios=bonds,
        phase_separation_lower=interval(sep),
        population_tree_lower=interval(tree_min),
        stationary_probability_lower=interval(pmin),
        mean_dissipation_pivot_lower=interval(hB),
        same_input_dissipation_pivot_lower=interval(hT),
        active_coherence_witnesses=len(contributions),
        measured_variance_upper=interval(denominator_upper),
        measured_recall_lower=interval(recall),
    )


def run(bits, exponent, cells):
    flint.ctx.prec = bits
    dark_center.cache_clear()
    geom = geometry()
    centers = json.loads((HERE.parent / "bridge/certificates.json").read_text())[
        "records"
    ]
    rows = []
    for row in centers:
        js = [Fraction(*p) for p in row["couplings_as_integer_ratios"]]
        assert [
            Fraction(float(j))
            for j in np.random.default_rng(row["seed"]).uniform(-1, 1, 3)
        ] == js
        leaves = []

        def visit(point, radius, depth):
            bonds = [[v.numerator, v.denominator] for v in point]
            try:
                leaves.append(
                    certify_box(
                        row, bonds, arb(radius.numerator) / radius.denominator, geom
                    )
                )
                leaves[-1]["subdivision_depth"] = depth
            except ArithmeticError:
                if depth >= 5:
                    raise
                half = radius / 2
                for s in itertools.product((-1, 1), repeat=3):
                    visit([v + d * half for v, d in zip(point, s)], half, depth + 1)

        visit(js, Fraction(1, 2**exponent), 0)
        worst = min(arb(leaf["measured_recall_lower"]).lower() for leaf in leaves)
        if exponent == 9:
            assert worst > arb("5e-8"), "published uniform recall bound"
        assert (
            sum((Fraction(1, 8 ** q["subdivision_depth"]) for q in leaves), Fraction(0))
            == 1
        )
        summary = dict(
            seed=row["seed"],
            central_bonds=row["couplings_as_integer_ratios"],
            leaf_count=len(leaves),
            cells_by_depth=dict(
                sorted(Counter(q["subdivision_depth"] for q in leaves).items())
            ),
            measured_recall_lower=interval(worst),
        )
        for label in (
            "phase_separation_lower",
            "population_tree_lower",
            "stationary_probability_lower",
            "mean_dissipation_pivot_lower",
            "same_input_dissipation_pivot_lower",
        ):
            summary[label] = interval(min(arb(q[label]).lower() for q in leaves))
        if cells:
            summary["leaves"] = leaves
        rows.append(summary)
        print(
            f"PASS seed {row['seed']}: {len(leaves)} leaves, recall above {interval(worst)}",
            flush=True,
        )
    return dict(
        precision_bits=bits,
        gain_prefactor=8,
        shots=1000,
        common_box_halfwidth=f"2^-{exponent}",
        rows=rows,
    )


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Enable Python assertions.")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--receipt", type=Path)
    p.add_argument("--bits", type=int, default=256)
    p.add_argument("--exponent", type=int, default=9)
    p.add_argument(
        "--cells",
        action="store_true",
        help="also write the individual covering cells in the receipt",
    )
    args = p.parse_args()
    result = run(args.bits, args.exponent, args.cells)
    if args.receipt:
        args.receipt.write_text(json.dumps(result, indent=2) + "\n")
