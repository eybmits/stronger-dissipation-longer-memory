Fixed-drive coupling neighborhoods for the three-spin order law

From the extracted reviewer-materials root in the provided certificate
environment, run:

  python evidence/neighborhood_fixed/certify_boxes.py

Requires NumPy and python-flint 0.9.0. The script rebuilds receipt.json
with outward-rounded aggregate bounds for four closed cubes of side 1/16.
All three entries J12, J13 and J23 vary independently; other Hamiltonian and
jump parameters, drive amplitude, interval length and readout are held fixed.
Coupling centers are the exact binary rationals in bridge/certificates.json.
Only the elementary unit-loss geometry and basis utilities are imported from
the adjacent bridge/certify.py. No center certificate bound, fitted coefficient,
existing simulated outcome or root-finding guess enters this calculation.

Why the box tests are sufficient

1. For each subbox, let C stack the two maps X -> (X - O_u X O_u^T)/2
on symmetric 8-by-8 matrices, and v=I/sqrt(8). The Gramian is exactly
I - (T_D + T_D^T)/2. On trace-free matrices it is unchanged by adding vv^T.
At the exact subbox center its least singular value, after adding vv^T, is
at least 1/||inverse||_F. The resulting square root is a lower bound for the
least singular value of C on trace-free matrices. A perturbation of magnitude
at most r in each coupling changes the physical Hamiltonian by <=3r in
operator norm. The dark Hamiltonian is its compression. With step length
1/2, Duhamel's formula for its unitary commutator thus bounds the change in
each dark orthogonal map by 3r. Each conjugation T_u changes by <=6r in
the induced Hilbert-Schmidt norm. The stacked map changes by <=sqrt(18)r.
The script subtracts that quantity at every closed subbox. Positivity excludes
a second invariant covariance. In dimension eight a unit-modulus eigenvector x
of the mean O would yield a nonscalar invariant real covariance Re(xx*):
the two rotations would have to act on x by the same phase.

2. Let G=h R^flat H R and K=-h R^flat H S H R, with H the full Hamiltonian
commutator. In dark traceless coordinates the sign-specific affine drift
evaluated on rho_D=I_D/3 is b=(d exp_G[K]) rho_D. The projected endpoint
terms give zero. If a is the traceless dark Hamiltonian of that sign,
its scalar product with z=(O-I)m_1+b equals its scalar product with b.
Both the observable a and rho_D are fixed by the dark unitary. The integral
formula for the exponential derivative therefore gives <a,z>=<a,K rho_D>.
The two sign innovations are opposite at the stationary mean, so
w >= |<a,K rho_D>|^2/(8 ||a||^2) using either sign.
The common scalar normalization used for a cancels. This test lower-bounds
writing without inverting a near-singular interval mean.

3. The traceless block F of d exp_G[K] gives the projected first derivative.
Both endpoint slips vanish. With the fixed covariance I and trace/8 dual,
kappa = -sum_u tr(F_u O_u^T)/8. For mean rotation O=(O_-+O_+)/2,
d0 = 1 - ||O||_F^2/8 = ||O_+-O_-||_F^2/32.
The code recomputes interval block exponentials on the whole subbox,
then encloses kappa, d0 and their ratio. No diagonalization with floating
eigenvectors is used. The visibility 1/6 depends only on the jump geometry.

Octree splits cover all eight children; boundary overlaps are harmless.
The integer volume check and the per-depth counts in receipt.json make the
coverage inspectable. The reported enclosures concern every fixed Hamiltonian
in the closed cubes; they do not set a common finite-loss accuracy threshold.
