"""Check the order--recall identity and crossover using density-matrix channels."""

import argparse
import json
from pathlib import Path
import numpy as np
from check import population, lindblad_step


def run():
    rows = []
    for eps in (1e-2, 1e-3, 1e-4, 1e-5, 1e-6):
        for exponent in (0.0, 0.25, 0.5, 0.75):
            theta = 0.8 * eps**exponent
            mean_y = (
                sum(lindblad_step(eps, theta, sign)[0][1, 1] for sign in (-1, 1)) / 2
            )
            horizon = int(np.ceil(np.log(0.1) / np.log(mean_y**2)))
            for shots in (1, 10, 1000):
                mom = population(eps, theta, shots)
                total = mom["variance"] / (
                    mom["variance"] + (1 - mom["variance"]) / shots
                )
                fraction = mom["recall"] / total
                predicted = 2 * mean_y**2 / (mom["mean_order"] + 1)
                error = abs(fraction / predicted - 1)
                assert error < 1e-8
                rows.append(
                    dict(
                        eps=eps,
                        exponent=exponent,
                        shots=shots,
                        mean_order=mom["mean_order"],
                        horizon=horizon,
                        past=mom["recall"],
                        total=total,
                        fraction=float(fraction),
                        identity_relative_error=float(error),
                    )
                )
    close = [
        r
        for r in rows
        if r["eps"] == 1e-6 and r["exponent"] == 0.25 and r["shots"] == 1
    ][0]
    product = close["eps"] * close["horizon"] * close["mean_order"]
    expected = 2 * np.log(10) / 3
    assert abs(product / expected - 1) < 0.01
    return {
        "method": "Full two-sign GKSL exponentials and independent stationary and order moment solves",
        "intermediate_exponent": 0.25,
        "eps_H_mean_order": product,
        "limiting_product": expected,
        "max_identity_relative_error": max(r["identity_relative_error"] for r in rows),
        "cells": rows,
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--receipt", type=Path)
    opt = p.parse_args()
    result = run()
    if opt.receipt:
        opt.receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(
        len(result["cells"]),
        result["max_identity_relative_error"],
        result["eps_H_mean_order"],
        result["limiting_product"],
    )
