"""Zeno-limit and finite-rate covariance-order audit for the physical spin maps."""

from __future__ import annotations

import os

for var in (
    "OPENBLAS_NUM_THREADS",
    "OMP_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "MKL_NUM_THREADS",
):
    os.environ[var] = "1"
from pathlib import Path
import sys, json
import numpy as np
import scipy.linalg as la
from scipy.sparse.linalg import LinearOperator, gmres

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "spin"))
from replay import SpinModel, SEEDS, SHOTS, SteinSolver, symmetric


def dark_isometry():
    columns = np.zeros((8, 3))
    columns[0, 0] = 1
    one_ex = [4, 2, 1]
    columns[one_ex, 1] = np.array([0, 1, -1]) / np.sqrt(2)
    columns[one_ex, 2] = np.array([2, 1, 1]) / np.sqrt(6)
    return columns


def hermitian_qutrit_basis():
    operators = [np.eye(3) / np.sqrt(3)]
    for i in range(3):
        for j in range(i + 1, 3):
            op = np.zeros((3, 3), complex)
            op[i, j] = op[j, i] = 2**-0.5
            operators.append(op)
            op = np.zeros((3, 3), complex)
            op[i, j] = -1j * 2**-0.5
            op[j, i] = op[i, j].conjugate()
            operators.append(op)
    operators += [np.diag([1, -1, 0]) / np.sqrt(2), np.diag([1, 1, -2]) / np.sqrt(6)]
    return np.array(operators)


def geometry(model):
    W = dark_isometry()
    dq = hermitian_qutrit_basis()
    embedded = np.array([W @ op @ W.T for op in dq])
    R = np.einsum("aij,bji->ab", np.array(model.ops), embedded).real / np.sqrt(8)
    left = la.null_space(model.loss.T)
    L = left @ la.inv(R.T @ left)
    P = R @ L.T
    S = la.inv(model.loss + P) - P
    assert la.norm(L.T @ R - np.eye(9)) < 1e-12
    assert la.norm(S @ model.loss - (np.eye(64) - P)) < 1e-11
    return R, L, S


def sym_basis(d):
    matrices = []
    for i in range(d):
        for j in range(i + 1):
            Q = np.zeros((d, d))
            if i == j:
                Q[i, i] = 1
            else:
                Q[i, j] = Q[j, i] = 2**-0.5
            matrices.append(Q.ravel())
    return np.array(matrices).T


def limit(model, gain):
    R, L, S = geometry(model)
    rhoD = R[:, 0] / np.sqrt(3)
    B = R[1:, 1:]
    left = L[1:, 1:].T
    zeno_maps = []
    derivatives = []
    rotations = []
    for u in (-1, 1):
        H = model.static + u * gain * model.drive
        projected = L.T @ H @ R
        E, dE = la.expm_frechet(0.5 * projected, -0.5 * (L.T @ H @ S @ H @ R))
        zeno_maps.append(R @ E @ L.T)
        derivatives.append(-S @ H @ R @ E @ L.T - R @ E @ L.T @ H @ S + R @ dE @ L.T)
        rotations.append(E[1:, 1:])
        assert la.norm(E[1:, 1:].T @ E[1:, 1:] - np.eye(8)) < 1e-12
    A0 = [x[1:, 1:] for x in zeno_maps]
    A1 = [x[1:, 1:] for x in derivatives]
    b1 = [(x @ rhoD)[1:] for x in derivatives]
    Ob = sum(rotations) / 2
    T = sum(np.kron(x, x) for x in rotations) / 2
    basis = sym_basis(8)
    T = basis.T @ T @ basis
    sv_T = la.svdvals(np.eye(36) - T)
    d0 = 1 - np.linalg.norm(Ob, "fro") ** 2 / 8
    out = {
        "first_moment_spectral_radius": max(abs(la.eigvals(Ob))),
        "first_moment_smin_I_minus_O": la.svdvals(np.eye(8) - Ob)[-1],
        "second_moment_smin_nontrivial_I_minus_T": sv_T[-2],
        "second_moment_fixed_dimension_at_1e-9": int(np.sum(sv_T < 1e-9)),
        "denominator": d0,
    }
    if gain == 0:
        return out
    R0 = B @ B.T
    ell = lambda X: np.trace(left @ X @ left.T) / 8
    m1 = la.solve(np.eye(63) - sum(A0) / 2, sum(b1) / 2)
    zs = np.array([a @ m1 + b - m1 for a, b in zip(A0, b1)])
    write = ell(zs.T @ zs / 2)
    derivative = sum(a1 @ R0 @ a0.T + a0 @ R0 @ a1.T for a0, a1 in zip(A0, A1)) / 2
    loss = -ell(derivative)
    beta = loss / d0
    i = model.index[(1, 0, 0)] - 1
    out.update(
        {
            "kappa": loss,
            "projected_write_w": write,
            "beta": beta,
            "scalar_x1_dark_overlap": R0[i, i],
            "scalar_x1_limit_pauli_variance_over_epsilon": 8 * write / loss * R0[i, i],
            "J": model.couplings,
        }
    )
    return out


def solve_weighted(V, A, D, stein, z):
    shape = A.shape

    def operator(v):
        x = v.reshape(shape)
        return (x - A @ x @ A.T - z * (D @ x @ D.T)).ravel()

    op = LinearOperator((A.size, A.size), matvec=operator, dtype=float)
    pre = LinearOperator(
        op.shape, matvec=lambda v: stein.solve(v.reshape(shape)).ravel(), dtype=float
    )
    sol, info = gmres(op, V.ravel(), M=pre, rtol=2e-11, atol=0, restart=70, maxiter=160)
    if info:
        raise RuntimeError(f"moment solver failed {info}")
    return symmetric(sol.reshape(shape))


def finite(model, gamma, gain, beta):
    maps, _, _ = model.maps(gamma, gain)
    (Am, bm), (Ap, bp) = maps
    A = (Ap + Am) / 2
    D = (Ap - Am) / 2
    m = la.solve(np.eye(63) - A, (bp + bm) / 2)
    v = D @ m + (bp - bm) / 2
    V = np.outer(v, v)
    solver = SteinSolver(A)
    cov = solve_weighted(V, A, D, solver, 1)
    Q = solve_weighted(V + D @ cov @ D.T, A, D, solver, 1)
    features = model.features - 1
    ix = np.ix_(features, features)
    obs = la.inv(cov[ix] + model.noise(m, cov) / SHOTS)
    score = lambda X: np.sum(obs * X[ix])
    i = model.index[(1, 0, 0)] - 1
    data = {
        "gamma": gamma,
        "var_x1": cov[i, i],
        "mean_order_x1": Q[i, i] / cov[i, i],
        "scaled_mean_x1": beta * Q[i, i] / cov[i, i] / gamma,
        "mean_order_grouped": score(Q) / score(cov),
        "scaled_mean_grouped": beta * score(Q) / score(cov) / gamma,
        "mean_map_radius": max(abs(la.eigvals(A))),
        "laplace": [],
    }
    for s in (0.25, 1, 4):
        z = np.exp(-s * beta / gamma)
        L = z * solve_weighted(V, A, D, solver, z)
        data["laplace"].append(
            {
                "s": s,
                "predicted": 1 / (1 + s),
                "x1": L[i, i] / cov[i, i],
                "grouped": score(L) / score(cov),
            }
        )
    return data


if __name__ == "__main__":
    report = []
    for seed in SEEDS:
        spin = SpinModel(3, seed)
        fixed = limit(spin, 1)
        matched_limit = limit(spin, 0)
        f = [
            finite(spin, g, 1, fixed["beta"])
            for g in (256, 1024, 4096, 16384, 65536, 262144)
        ]
        row = {
            "seed": seed,
            "fixed": fixed,
            "matched_limit": matched_limit,
            "finite": f,
        }
        report.append(row)
        print(
            seed,
            json.dumps(fixed),
            [
                (
                    x["gamma"],
                    x["scaled_mean_x1"],
                    x["scaled_mean_grouped"],
                    x["laplace"][1],
                )
                for x in f
            ],
            flush=True,
        )
    (HERE / "spin_bridge.json").write_text(json.dumps(report, indent=2) + "\n")
