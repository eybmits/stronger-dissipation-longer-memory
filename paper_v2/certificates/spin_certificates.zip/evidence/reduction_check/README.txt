Full-map check of the limiting spin reduction

From the extracted data or standalone certificate root:
  python evidence/reduction_check/check.py --receipt my-reduction.json

The model builder constructs the full 64-coordinate dissipator independently
in a Hermitian matrix-unit basis and obtains the dark Hilbert space and
stationary projection via null spaces. Ordered Duhamel quadratures form the
slow-generator derivatives; no fitted memory or extrapolated readout is used.
Compare to the directly exponentiated full Lindblad step at loss rates 256,
512, 1024, 2048 and 4096 for all four original Hamiltonians. The fixed-drive
prediction retains both endpoint terms on all input/output coordinates. The
negative control deliberately omits those terms. With matched drive, project
the full step on the dark coordinates and test its mean and sign-dependent
half-difference separately. result.json gives Frobenius residuals and ratios
at every pair of rates. These comparisons are floating-point diagnostics.
The analytic derivation and the interval certificate are separate.
