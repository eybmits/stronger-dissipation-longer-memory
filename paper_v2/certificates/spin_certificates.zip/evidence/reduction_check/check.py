"""Test the slow-step expansion on whole channel matrices, before solving readout moments."""

import argparse
import json
from pathlib import Path
import sys
import numpy as np
from scipy import linalg as la
from scipy.special import roots_legendre

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "certificate_review"))
from finite_rate import FullModel

SEEDS = (8675309, 424242, 97531, 123457)
LOSSES = (256, 512, 1024, 2048, 4096)


def integrals(g, j, c, nodes):
    """First variation, and one insertion of c plus two ordered insertions of j."""
    t, weights = roots_legendre(nodes)
    grid, weights = (1 + t) / 2, weights / 2
    first = np.zeros_like(g)
    second = np.zeros_like(g)
    for t, w in zip(grid, weights):
        before, after = la.expm(t * g), la.expm((1 - t) * g)
        first += w * after @ j @ before
        second += w * after @ c @ before
        for v, vweight in zip(grid, weights):
            second += (
                w
                * t
                * vweight
                * after
                @ j
                @ la.expm(t * (1 - v) * g)
                @ j
                @ la.expm(t * v * g)
            )
    return first, second


def audit(seed):
    model = FullModel(np.random.default_rng(seed).uniform(-1, 1, 3))
    r, l, d = model.R, model.left, model.diss
    pr = r @ l
    s = la.solve(d + pr, np.eye(len(pr))) - pr
    np.testing.assert_allclose(d @ s, np.eye(len(pr)) - pr, atol=1e-11)
    h = 0.5
    g = h * l @ model.static @ r
    j = h * 8 * l @ model.drive @ r
    c = -h * l @ model.static @ s @ model.static @ r
    first, second = integrals(g, j, c, 12)
    high = integrals(g, j, c, 18)
    quadrature = max(la.norm(a - b) for a, b in zip((first, second), high))
    assert quadrature < 1e-11
    rot = model.unitary_step(0)
    fixed = []
    for sign in (-1, 1):
        H = model.static + sign * model.drive
        u = model.unitary_step(sign)
        # A single Duhamel integral for the fixed-drive generator correction.
        t, weights = roots_legendre(18)
        gd = h * l @ H @ r
        cd = -h * l @ H @ s @ H @ r
        derivative = sum(
            w / 2 * la.expm((1 - tp) / 2 * gd) @ cd @ la.expm((1 + tp) / 2 * gd)
            for tp, w in zip(t, weights)
        )
        base = r @ u @ l
        reduced_only = r @ derivative @ l
        full = reduced_only - s @ H @ base - base @ H @ s
        fixed.append((sign, base, full, reduced_only))
    errors = {
        label: []
        for label in (
            "fixed_minus",
            "fixed_plus",
            "omit_slips_minus",
            "omit_slips_plus",
            "projected_mean",
            "projected_difference",
        )
    }
    for gamma in LOSSES:
        e = 1 / gamma
        for sign, base, full, reduced_only in fixed:
            label = "minus" if sign < 0 else "plus"
            finite = model.full_step(e, sign)
            errors["fixed_" + label].append(float(la.norm(finite - base - e * full)))
            errors["omit_slips_" + label].append(
                float(la.norm(finite - base - e * reduced_only))
            )
        maps = [l @ model.full_step(e, sign * 8 * np.sqrt(e)) @ r for sign in (-1, 1)]
        errors["projected_mean"].append(
            float(la.norm((maps[0] + maps[1]) / 2 - rot - e * second))
        )
        errors["projected_difference"].append(
            float(la.norm((maps[1] - maps[0]) / 2 - np.sqrt(e) * first))
        )
    slopes = {k: np.log2(np.array(v[:-1]) / v[1:]).tolist() for k, v in errors.items()}
    expected = {
        "fixed_minus": 2,
        "fixed_plus": 2,
        "omit_slips_minus": 1,
        "omit_slips_plus": 1,
        "projected_mean": 2,
        "projected_difference": 1.5,
    }
    assert all(abs(slopes[k][-1] - power) < 0.045 for k, power in expected.items())
    return {
        "seed": seed,
        "max_quadrature_change": quadrature,
        "frobenius_errors": errors,
        "successive_orders": slopes,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    result = {"losses": LOSSES, "cells": [audit(s) for s in SEEDS]}
    for cell in result["cells"]:
        print(
            cell["seed"],
            {k: round(v[-1], 4) for k, v in cell["successive_orders"].items()},
        )
    if args.receipt:
        args.receipt.write_text(json.dumps(result, indent=2) + "\n")
