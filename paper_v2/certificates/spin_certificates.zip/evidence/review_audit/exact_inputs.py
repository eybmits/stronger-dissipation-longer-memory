"""Independent integer Pauli algebra and exact rational dark-spectrum audit.

Compare the certificate producers' microscopic inputs with two different
constructions. No random floating-point diagonalization is used to count roots.
"""

import argparse
import itertools
import json
import sys
from pathlib import Path

import flint
from flint import arb, fmpq, fmpq_mat

HERE = Path(__file__).resolve().parent
WORDS = list(itertools.product(range(4), repeat=3))
INDEX = {word: i for i, word in enumerate(WORDS)}


def multiply(*terms):
    word = [0, 0, 0]
    phase = 0
    for term in terms:
        for k, b in enumerate(term):
            a = word[k]
            if a and b and a != b:
                phase += 1 if (a, b) in ((1, 2), (2, 3), (3, 1)) else -1
                word[k] = 6 - a - b
            elif a == b:
                word[k] = 0
            else:
                word[k] = a or b
    return INDEX[tuple(word)], phase % 4


def site(axis, pos):
    return tuple(axis if j == pos else 0 for j in range(3))


def physical_generators():
    """Return exact real PTM coefficients as integers divided by eight."""
    jump = [
        (site(a, i), sign, phase)
        for i, sign in enumerate((1, -1, -1))
        for a, phase in [(1, 0), (2, 1)]
    ]
    h0 = [(site(3, i), 4) for i in range(3)] + [(site(1, i), 6) for i in range(3)]
    hd = [(site(1, i), 2) for i in range(3)]
    pairs = [
        tuple(1 if k in (i, j) else 0 for k in range(3))
        for i, j in itertools.combinations(range(3), 2)
    ]
    result = []
    for col, word in enumerate(WORDS):
        channels = [[[0, 0] for _ in range(64)] for _ in range(6)]

        def add(channel, sequence, phase, coeff):
            row, q = multiply(*sequence)
            q = (q + phase) % 4
            channels[channel][row][q % 2] += coeff if q < 2 else -coeff

        # J P J* -(J*J P + P J*J)/2. Phases for J* are conjugated.
        for u, s, p in jump:
            for v, t, q in jump:
                for seq, c in [
                    ((u, word, v), 2),
                    ((v, u, word), -1),
                    ((word, v, u), -1),
                ]:
                    add(0, seq, p - q, s * t * c)
        for k, terms in enumerate([h0, hd] + [[(pair, 8)] for pair in pairs], 1):
            for u, c in terms:
                # -i [H,P].
                add(k, (u, word), -1, c)
                add(k, (word, u), 1, c)
        if any(im for channel in channels for _, im in channel):
            raise ArithmeticError("Hermitian generator has imaginary PTM coefficients")
        result.append([[real for real, _ in channel] for channel in channels])
    return result


def dark_polynomial(couplings):
    """Generalized dark Hamiltonian in an integer, nonnormalized basis."""
    zero = fmpq(0)
    h = fmpq_mat(8, 8)
    for col in range(8):
        h[col, col] = sum(
            (fmpq(-1 if col & (1 << i) else 1, 2) for i in range(3)), zero
        )
        for bit in (4, 2, 1):
            h[col ^ bit, col] += fmpq(3, 4)
        for (i, j), c in zip(itertools.combinations((4, 2, 1), 2), couplings):
            h[col ^ i ^ j, col] += c
    v = fmpq_mat(8, 3)
    v[0, 0] = 1
    for idx, a, b in zip((4, 2, 1), (0, 1, -1), (2, 1, 1)):
        v[idx, 1], v[idx, 2] = a, b
    return ((v.transpose() * v).inv() * v.transpose() * h * v).charpoly()


def sturm_chain(poly):
    sequence = [poly, poly.derivative()]
    while True:
        remainder = -(sequence[-2] % sequence[-1])
        if not remainder:
            return sequence
        sequence.append(remainder)


def variations(chain, x):
    vals = [p(x) for p in chain]
    signs = [v > 0 for v in vals if v]
    return sum(a != b for a, b in zip(signs, signs[1:]))


def dyadic_floor(mid, bits):
    man, exponent = mid.man_exp()
    numerator = int(man)
    shift = int(exponent) + bits
    return numerator << shift if shift >= 0 else numerator // (1 << (-shift))


def audit(evidence):
    sys.path.insert(0, str(evidence / "bridge"))
    from certify import geometry
    from certify_matched import hamiltonian

    flint.ctx.prec = 256
    d, _, _, _, base, drive, pairs = geometry()
    matrices = [d, base, drive, *pairs]
    fields = physical_generators()
    for col, channels in enumerate(fields):
        for matrix, coeff in zip(matrices, channels):
            for row, real in enumerate(coeff):
                if matrix[row, col] != arb(real) / 8:
                    raise ArithmeticError(
                        f"Generator coefficient differs at row {row}, column {col}"
                    )
    records = json.loads((evidence / "bridge/certificates.json").read_text())["records"]
    rows = []
    for record in records:
        seed = record["seed"]
        hd, _ = hamiltonian(seed)
        eigen = sorted(hd.eig(), key=lambda z: float(z.real.mid()))
        if len(eigen) != 3 or not all(z.imag.contains(0) for z in eigen):
            raise ArithmeticError(
                "Invalid eigenvalue enclosures for a Hermitian Hamiltonian"
            )
        couplings = [fmpq(n, d) for n, d in record["couplings_as_integer_ratios"]]
        poly = dark_polynomial(couplings)
        chain = sturm_chain(poly)
        bounds = []
        denom = 1 << 150
        for z in eigen:
            lower = dyadic_floor(z.real.mid(), 150)
            left, right = fmpq(lower, denom), fmpq(lower + 1, denom)
            if not (arb(left) < z.real < arb(right)):
                raise ArithmeticError(
                    "The exact rational bracket does not strictly contain the Arb enclosure"
                )
            count = variations(chain, left) - variations(chain, right)
            if count != 1 or poly(left) == 0 or poly(right) == 0:
                raise ArithmeticError("Eigenvalue isolation failed")
            bounds.append(lower)
        if not bounds[0] + 1 < bounds[1] < bounds[2] - 1:
            raise ArithmeticError("Overlapping exact root brackets")
        rows.append(
            {
                "seed": seed,
                "monic_polynomial_coefficients": [str(poly[i]) for i in range(4)],
                "denominator": str(denom),
                "left_numerators": [str(v) for v in bounds],
                "root_counts": [1, 1, 1],
            }
        )
    return {
        "status": "pass",
        "generator_entries_compared": 6 * 64 * 64,
        "construction": "integer Pauli multiplication for dissipator, static Hamiltonian, input drive and three pair generators",
        "spectral_construction": "rational projected Hamiltonian from an unnormalized integer dark basis, exact Sturm isolation at width 2^-150",
        "python_flint": flint.__version__,
        "rows": rows,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=HERE.parent)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    result = audit(args.evidence)
    if args.receipt:
        args.receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(
        "PASS: all 24,576 microscopic generator entries and all twelve exact Sturm root counts."
    )
