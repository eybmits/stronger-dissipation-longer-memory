Reader's guide to the spin proofs and their verification

Setup
Unzip the package, install certificate-requirements.txt in a Python 3.13
environment, then run python verify_certificates.py. The optional argument
--receipt local.json saves the reconstruction. An assertion-enabled Python
build is required. The inputs are four Hamiltonians with three exact bond coefficients each,
the stated mixed-sign loss, and a scalar spin readout.

What the files check
1. Exact inputs. The dyadic couplings archived for each seed and six
microscopic generator matrices are independently checked. Running
python evidence/review_audit/exact_inputs.py reconstructs 24,576 Pauli entries
using integer Pauli-word products. A separately assembled rational matrix
in an integer dark basis has three real roots; exact Sturm counts isolate each
one in a disjoint interval of width 2^-150 containing its Arb enclosure.
The twelve root counts and exact cubic coefficients are in exact_inputs.json.

2. Fixed gain. For the centered traceless map, a norm bound on a power proves
mixing. A bordered twirl inverse proves uniqueness of the fixed covariance
shape; the computed writing, damping and visibility factors are strictly
positive. The proof shows why this gives the order law. The separate box calculation in evidence/neighborhood_fixed/ certifies
closed neighborhoods of the three static XX couplings at fixed drive.

3. Matched gain. The dark phases are distinct, the population generator is
irreducible, and the two secular covariance generators have strictly positive
Routh-Hurwitz leading minors. The observed past Gramian and variance are
positive. The limiting tail crosses 0.1 inside the certified horizon bracket.
The theorem justifies the perturbation expansion and the identification of
these finite matrices with limiting observables. The matched coupling-box calculation at prefactor 8 covers every point
in four boxes of half-width 1/512. It checks a separate positive lower bound
for limiting recall as well as phase separation and strict stability.
The central 192- and 256-bit checks
evaluate the finite inequalities. A separate full-matrix finite-rate
extrapolation checks the resulting constants numerically.

4. Prefactor interval. For the four original Hamiltonians and one measured
X observable, replace eta by g/sqrt(gamma) and let x=g^2. Positivity of twenty
polynomials on [4,1024] verifies the irreducibility, stability and signal
conditions for each fixed g in [2,32]. The coefficient test is rerun at 256
and 512 bits. It establishes positivity of limiting recall and scaled horizon
throughout this interval, without asserting equal performance for every g.

Scope of this audit
These are reproducible computer-assisted numerical and exact arithmetic
checks, plus a mathematical explanation of what each check is used for.
The full-step residual test in evidence/reduction_check/ uses direct
exponentials and ordered quadratures to check the expansion before projecting
to a particular readout. Specialist assessment of the analytic proofs remains
separate from these computational checks. The individual task, cost and shot data are in reviewer_materials.zip.
The compact PDF attachment covers the certificates for the four three-spin
Hamiltonians. The complete application benchmarks are in reviewer_materials.zip.
