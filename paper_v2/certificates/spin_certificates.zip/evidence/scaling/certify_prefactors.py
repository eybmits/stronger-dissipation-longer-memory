"""Rerun the matched spin proof's strict tests at five prescribed, positive input coefficients."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "bridge"))
from certify import geometry
from certify_matched import make_certificate
from matched import matched
import flint
from flint import arb

CONFIG = json.loads((HERE / "certificate_protocol.json").read_text())
GRID = json.loads((HERE / "protocol.json").read_text())


def run(output):
    seeds = GRID["seeds"]
    coefficients = CONFIG["coefficients_in_eta_equals_c_over_sqrt_gamma"]
    rows = []
    for bits in CONFIG["precision_bits"]:
        flint.ctx.prec = bits
        base = geometry()
        for c in coefficients:
            # In the bridge routine G_d = (h*8) R^flat H_d R. Rescale only H_d
            # by c/8, leaving the static Hamiltonian, bath and disorder unchanged.
            geom = list(base)
            geom[5] = geom[5] * (arb(c) / 8)
            for seed in seeds:
                estimate = matched(seed, gain_scale=c)["x1_scaled_horizon_limit"]
                result = make_certificate(seed, geom, estimate)
                rows.append({"bits": bits, "coefficient": c, **result})
    for lo, hi in zip(rows[:20], rows[20:]):
        assert (lo["seed"], lo["coefficient"]) == (hi["seed"], hi["coefficient"])
        assert lo["scaled_horizon_bracket"] == hi["scaled_horizon_bracket"]
        for k in (
            "X1_limiting_past_recall",
            "X1_positive_linear_gramian",
            "min_population_offdiag",
        ):
            assert arb(lo[k]).overlaps(arb(hi[k]))
    results = dict(
        protocol_sha256=hashlib.sha256(
            (HERE / "certificate_protocol.json").read_bytes()
        ).hexdigest(),
        python_flint=flint.__version__,
        rows=rows,
    )
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(
        "Passed both precisions for all 20 scalar spin matched coefficients / Hamiltonians."
    )


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Certificate assertions require ordinary Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=HERE / "prefactor_certificates.json"
    )
    run(parser.parse_args().output)
