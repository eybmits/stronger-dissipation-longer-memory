"""Stationary linear recall with a common loss-only recovery, with/without dephasing."""
import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","VECLIB_MAXIMUM_THREADS","MKL_NUM_THREADS"):
    os.environ[key]="1"

import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy import linalg as la

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/"certificate_review"))
from finite_rate import FullModel, hermitian_basis

P=json.loads((HERE/"protocol.json").read_text())
SHA=hashlib.sha256((HERE/"protocol.json").read_bytes()).hexdigest()
assert SHA==(HERE/"protocol.sha256").read_text().strip()


def score(channels, observable):
    # Trace-one density coordinates have first component 1/sqrt(3).
    trace_error=max(la.norm(q[0]-np.eye(1,len(q))[0]) for q in channels)
    assert trace_error<5e-9
    a,d=np.mean(channels,axis=0),(channels[1]-channels[0])/2
    mean=la.solve(np.eye(len(a)-1)-a[1:,1:],a[1:,0]/np.sqrt(3))
    mean_full=np.r_[1/np.sqrt(3),mean]
    mu=observable@mean_full
    innovation=(d@mean_full)[1:]
    a,d=a[1:,1:],d[1:,1:]
    n=len(a)
    source=np.outer(innovation,innovation)
    full=np.kron(a,a)+np.kron(d,d)
    sigma=la.solve(np.eye(n*n)-full,source.ravel()).reshape(n,n)
    gram=la.solve_discrete_lyapunov(a,source)
    past=a@gram@a.T
    res=max(la.norm(sigma-a@sigma@a.T-d@sigma@d.T-source),
            la.norm(gram-a@gram@a.T-source))/max(1e-300,la.norm(source))
    assert res<5e-8 and max(abs(la.eigvals(full)))<1
    x=observable[1:]
    variance=x@sigma@x
    single_noise=1-mu**2-variance
    assert single_noise>1/3-1e-10 and variance>=0
    past_weight=x@past@x
    gain=past_weight/(variance+single_noise/P["shots"])
    return dict(gain=float(gain),past_gramian=float(past_weight),signal_variance=float(variance),
                single_shot_variance=float(single_noise),mean=float(mu),innovation_norm=float(la.norm(innovation)),
                stationarity_relative_residual=float(res),trace_error=float(trace_error))


def central(seed):
    model=FullModel(np.random.default_rng(seed).uniform(-1,1,3))
    # Q embeds a real orthonormal identity + two population contrasts into
    # the same Hermitian qutrit coordinates as the coherent channel.
    _,states=la.eigh(model.hdark)
    pops=[states[:,i:i+1]@states[:,i:i+1].conj().T for i in range(3)]
    basis=hermitian_basis(3)
    diagonals=np.array([np.eye(3)/np.sqrt(3),(pops[0]-pops[1])/np.sqrt(2),
                       (pops[0]+pops[1]-2*pops[2])/np.sqrt(6)])
    q=np.einsum("aij,bji->ab",basis,diagonals).real
    np.testing.assert_allclose(q.T@q,np.eye(3),rtol=0,atol=2e-14)
    x=np.einsum("aij,ji->a",basis,model.xdark).real
    rows=[]
    for gamma in P["gamma"]:
        gain=P["gain_prefactor"]/np.sqrt(gamma)
        channels=[model.left@model.full_step(1/gamma,s*gain)@model.R for s in (-1,1)]
        choi_min=1.
        for ch in channels:
            p=model.q@ch@model.q.conj().T
            choi=p.reshape((3,)*4,order="F").transpose(0,2,1,3).reshape(9,9)
            choi_min=min(choi_min,la.eigvalsh((choi+choi.conj().T)/2)[0])
        assert choi_min>-1e-9
        diagonal=[q.T@ch@q for ch in channels]
        rows.append(dict(seed=seed,gamma=gamma,recovered=score(channels,x),
                         dephased=score(diagonal,q.T@x),min_recovered_choi=float(choi_min),
                         scaled_dephased_half_difference=float(la.norm((diagonal[1]-diagonal[0])/2)*gamma**1.5)))
    return rows


if __name__=="__main__":
    rows=[row for seed in P["seeds"] for row in central(seed)]
    output=dict(protocol_sha256=SHA,rows=rows)
    (HERE/"results.json").write_text(json.dumps(output,indent=2)+"\n")
    for row in rows:
        print(row["seed"],row["gamma"],row["recovered"]["gain"],row["dephased"]["gain"])
