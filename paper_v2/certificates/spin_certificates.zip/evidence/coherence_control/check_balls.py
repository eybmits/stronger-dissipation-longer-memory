"""Independent finite-rate enclosure in the exact Pauli basis using Arb."""

import argparse
import json
from pathlib import Path
import sys
import flint
from flint import arb, arb_mat as M

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "neighborhood_matched"))
from verify import spectral_data, negative_symmetric_part
from certify import geometry, eye, block, interval
from certify_matched import qutrit_basis

flint.ctx.prec = 256
P = json.loads((HERE / "protocol.json").read_text())


def moments(plus, minus, x, shots):
    n = plus.nrows() - 1
    a_full, d_full = (plus + minus) / 2, (plus - minus) / 2
    tr = range(1, n + 1)
    a, d = block(a_full, tr, tr), block(d_full, tr, tr)
    m = (eye(n) - a).solve(block(a_full, tr, [0]) / arb(3).sqrt())
    v = d * m + block(d_full, tr, [0]) / arb(3).sqrt()
    mu = x[0, 0] / arb(3).sqrt() + (block(x, tr, [0]).transpose() * m)[0, 0]
    source = v * v.transpose()
    coords = [(i, j) for i in range(n) for j in range(n)]

    def lift(g):
        return M([[g[i, k] * g[j, l] for k, l in coords] for i, j in coords])

    def unpack(z):
        return M([[z[i * n + j, 0] for j in range(n)] for i in range(n)])

    rhs = M([[source[i, j]] for i, j in coords])
    b = eye(n * n) - lift(a)
    s = b - lift(d)
    # A positive adjoint Lyapunov witness proves mean-square stability.
    # The strict decrement is I. This also stabilizes the mean-product map.
    metric = unpack(s.transpose().solve(M([[int(i == j)] for i, j in coords])))
    pivot = negative_symmetric_part(-metric / 2)
    sigma = unpack(s.solve(rhs))
    gram = unpack(b.solve(rhs))
    aobs = block(x, tr, [0])
    variance = (aobs.transpose() * sigma * aobs)[0, 0]
    noise = 1 - mu**2 - variance
    assert noise > arb("0.33") and variance > 0
    score = (aobs.transpose() * a * gram * a.transpose() * aobs)[0, 0] / (
        variance + noise / shots
    )
    assert score > 0
    return score, pivot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path, default=HERE / "ball_receipt.json")
    options = parser.parse_args()
    seeds = json.loads((HERE.parent / "bridge" / "certificates.json").read_text())[
        "records"
    ]
    reference = json.loads((HERE / "results.json").read_text())["rows"]
    diss, R, L, S, static, drive, pairs = geometry()
    tb = qutrit_basis()
    # Columns: identity and trace-zero population contrasts in the energy basis.
    ch = M(
        [
            [1 / arb(3).sqrt(), 1 / arb(2).sqrt(), 1 / arb(6).sqrt()],
            [1 / arb(3).sqrt(), -1 / arb(2).sqrt(), 1 / arb(6).sqrt()],
            [1 / arb(3).sqrt(), 0, -2 / arb(6).sqrt()],
        ]
    )
    checks = []
    for row in seeds:
        couplings = row["couplings_as_integer_ratios"]
        proj, _, _, xop, _, _ = spectral_data(row, couplings, arb(0))
        pop = proj * ch
        x = M([[(op * xop).trace().real] for op in tb])
        h = static + sum(
            (arb(n) / d * term for (n, d), term in zip(couplings, pairs)), M(64, 64)
        )
        for gamma in P["gamma"]:
            signed = [
                L
                * (
                    (
                        gamma * diss
                        + h
                        + s * (P["gain_prefactor"] / arb(gamma).sqrt()) * drive
                    )
                    / 2
                ).exp()
                * R
                for s in (-1, 1)
            ]
            dep = [pop.transpose() * u * pop for u in signed]
            with_coherence, coherent_pivot = moments(
                signed[1], signed[0], x, P["shots"]
            )
            dephased, dephased_pivot = moments(
                dep[1], dep[0], pop.transpose() * x, P["shots"]
            )
            stored = next(
                t for t in reference if t["seed"] == row["seed"] and t["gamma"] == gamma
            )
            errors = {
                name: float(abs(arb(stored[name]["gain"]) / v - 1).abs_upper())
                for name, v in [("recovered", with_coherence), ("dephased", dephased)]
            }
            assert max(errors.values()) < 0.02, (row["seed"], gamma, errors)
            checks.append(
                dict(
                    seed=row["seed"],
                    gamma=gamma,
                    recovered=interval(with_coherence),
                    dephased=interval(dephased),
                    double_relative_difference=errors,
                    recovered_lyapunov_pivot_lower=interval(coherent_pivot),
                    dephased_lyapunov_pivot_lower=interval(dephased_pivot),
                )
            )
        print("Enclosed both channels at six loss rates, seed", row["seed"], flush=True)
    report = dict(
        precision_bits=flint.ctx.prec, python_flint=flint.__version__, rows=checks
    )
    options.receipt.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
