Spin certificate capsule for Temporal order of memory in protected quantum reservoirs

This small package verifies the collective-loss spin instances, certified coupling
neighborhoods, the continuous matched-drive coefficient interval, and the
finite-rate coherence intervention. It also includes the numerical
full-map check of the separate analytic three-level model. Its two numerical methods use Arb
intervals and independently extrapolated full density-matrix maps. It does not
require the larger task/trajectory archive. From this directory on macOS/Linux:

  python3.13 -m venv .cert
  .cert/bin/python -m pip install -r certificate-requirements.txt
  .cert/bin/python verify_certificates.py --receipt verified.json

To run the independent integer Pauli-algebra and exact Sturm-spectrum check
directly, use .cert/bin/python evidence/review_audit/exact_inputs.py. For the
independent numerical three-level check, see evidence/generality_extension/README.txt.

Reference replay used CPython 3.13.2. A normal run with assertions enabled must
print the four passing instances and the matched coefficient checks. This is
a local computational verification. The analytic proof and its hypotheses
remain in the paper. All additional study data are in reviewer_materials.zip,
available separately and as an ancillary file in the TeX submission.
